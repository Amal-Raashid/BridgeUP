import csv
import uuid
import shutil
import random
from pathlib import Path
from datetime import datetime, timedelta

from agents.orchestrator_agent.orchestrator import Orchestrator
from agents.orchestrator_agent.state import SessionState


# ============================================================
# Locked Paper Evaluation Schema
# ============================================================

CSV_HEADER = [
    "session_id",
    "strategy",
    "weekly_hours",
    "total_tasks",
    "completed_tasks",
    "missed_tasks",
    "completion_rate",
    "delay_index_hours",
    "workload_utilization",
    "stability_score",
    "dropoff_risk",
    "consistency_score",
]

STRATEGIES = ["fast", "balanced", "deep"]
WEEKLY_HOURS = [5, 10, 15]
RUNS_PER_SETTING = 10

OUTPUT_PATH = Path("paper_assets") / "03_metrics" / "metrics_v1.csv"


# ============================================================
# Clear Monitoring State
# ============================================================

def clear_monitoring_sessions():
    base = Path("data/monitoring_logs") / "sessions"
    if base.exists():
        shutil.rmtree(base)


# ============================================================
# Stochastic Behavioral Simulation
# ============================================================

def simulate_lifecycle(strategy, session_id, state, monitor, weekly_hours):

    schedule_blocks = state.execution_state.schedule_blocks

    # Group schedule blocks per task
    task_blocks = {}
    for block in schedule_blocks:
        task_blocks.setdefault(block.task_id, []).append(block)

    task_ids = sorted(task_blocks.keys())
    total_tasks = len(task_ids)

    # --------------------------------------------------------
    # Strategy behavior profiles with stochastic variation
    # --------------------------------------------------------

    if strategy == "fast":

        base_completion = random.uniform(0.50, 0.70)
        completion_delay_hours = random.uniform(-3, 1)
        miss_delay_hours = random.uniform(1, 4)

    elif strategy == "balanced":

        base_completion = random.uniform(0.75, 0.90)
        completion_delay_hours = random.uniform(-1, 2)
        miss_delay_hours = random.uniform(3, 6)

    else:  # deep

        base_completion = random.uniform(0.65, 0.85)
        completion_delay_hours = random.uniform(4, 8)
        miss_delay_hours = random.uniform(6, 10)

    # Slight effect of weekly hours
    hours_factor = 1 + (weekly_hours - 10) / 50
    completion_ratio = min(max(base_completion * hours_factor, 0.4), 0.95)

    completion_limit = int(total_tasks * completion_ratio)

    completed = 0
    missed = 0

    for i, task_id in enumerate(task_ids):

        blocks = sorted(task_blocks[task_id], key=lambda b: b.start_time)

        first_block = blocks[0]
        last_block = blocks[-1]

        scheduled_start = first_block.start_time
        scheduled_end = last_block.end_time
        deadline = scheduled_end

        # TASK_STARTED
        monitor.collector.record_task_event({
            "event_type": "TASK_STARTED",
            "task_id": task_id,
            "session_id": session_id,
            "timestamp": scheduled_start.isoformat(),
            "payload": {}
        })

        # COMPLETE OR MISS
        if i < completion_limit:

            delay_noise = random.uniform(-1, 1)
            completion_time = scheduled_end + timedelta(
                hours=completion_delay_hours + delay_noise
            )

            if completion_time <= scheduled_start:
                completion_time = scheduled_start + timedelta(hours=1)

            monitor.collector.record_task_event({
                "event_type": "TASK_COMPLETED",
                "task_id": task_id,
                "session_id": session_id,
                "timestamp": completion_time.isoformat(),
                "payload": {}
            })

            completed += 1

        else:

            delay_noise = random.uniform(-1, 1)
            miss_time = deadline + timedelta(
                hours=miss_delay_hours + delay_noise
            )

            monitor.collector.record_task_event({
                "event_type": "TASK_MISSED",
                "task_id": task_id,
                "session_id": session_id,
                "timestamp": miss_time.isoformat(),
                "payload": {}
            })

            missed += 1

    return completed, missed


# ============================================================
# Helpers
# ============================================================

def ensure_output_directory():
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)


def write_header_if_needed():
    if not OUTPUT_PATH.exists():
        with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(CSV_HEADER)


def append_row(row):
    with open(OUTPUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(row)


# ============================================================
# Experiment Runner
# ============================================================

def run_experiments():

    ensure_output_directory()
    write_header_if_needed()

    clear_monitoring_sessions()

    orchestrator = Orchestrator()

    total_runs = len(STRATEGIES) * len(WEEKLY_HOURS) * RUNS_PER_SETTING
    counter = 0

    print("=== Phase 2.5B Behavioral Evaluation (Stochastic) ===")
    print(f"Total runs: {total_runs}")
    print("----------------------------------------------")

    for strategy in STRATEGIES:
        for hours in WEEKLY_HOURS:
            for run in range(RUNS_PER_SETTING):

                counter += 1
                session_id = str(uuid.uuid4())
                state = SessionState(session_id=session_id)

                request_payload = {
                    "job_requirement": "Backend Developer",
                    "known_skills": [],
                    "weekly_time_hours": hours,
                    "strategy": strategy,
                    "request_type": "generate_plan_and_execute",
                    "start_date": datetime(2026, 1, 1),
                }

                print(f"[{counter}/{total_runs}] {strategy} | {hours}h | run {run+1}")

                orchestrator.handle_request(request_payload, state)

                completed, missed = simulate_lifecycle(
                    strategy,
                    session_id,
                    state,
                    orchestrator.monitor,
                    hours
                )

                orchestrator.monitor.collector.build_session_snapshot(
                    session_id=session_id,
                    weekly_hours_allocated=hours,
                    planned_days=5
                )

                metrics = orchestrator.monitor.get_session_metrics(session_id)

                row = [
                    session_id,
                    strategy,
                    hours,
                    len(state.execution_state.tasks),
                    completed,
                    missed,
                    metrics.completion_rate,
                    metrics.delay_index / 3600,
                    metrics.workload_utilization,
                    metrics.stability_score,
                    metrics.dropoff_risk_score,
                    metrics.consistency_score,
                ]

                append_row(row)

    print("----------------------------------------------")
    print("Evaluation complete.")
    print(f"Saved to: {OUTPUT_PATH}")


if __name__ == "__main__":
    run_experiments()