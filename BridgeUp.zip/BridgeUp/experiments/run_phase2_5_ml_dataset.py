import csv
import uuid
import hashlib
from pathlib import Path
from datetime import datetime

from agents.orchestrator_agent.orchestrator import Orchestrator
from agents.orchestrator_agent.state import SessionState

from experiments.run_phase2_5 import simulate_lifecycle


STRATEGIES = ["fast", "balanced", "deep"]
WEEKLY_HOURS = [5, 10, 15]

RUNS_PER_SETTING = 100   # increase dataset size

OUTPUT_PATH = Path("paper_assets/03_metrics/metrics_v2_large.csv")

CACHE_PATH = Path("paper_assets/03_metrics/cache_keys.txt")


CSV_HEADER = [
    "session_id",
    "strategy",
    "weekly_hours",
    "total_tasks",
    "completed_tasks",
    "missed_tasks",
    "completion_rate",
    "delay_index_hours",
    "workload_utilization",
    "stability_score",
    "dropoff_risk",
    "consistency_score",
]


def load_cache():
    if not CACHE_PATH.exists():
        return set()

    with open(CACHE_PATH) as f:
        return set(line.strip() for line in f.readlines())


def save_cache(key):
    with open(CACHE_PATH, "a") as f:
        f.write(key + "\n")


def ensure_output():
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    if not OUTPUT_PATH.exists():
        with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(CSV_HEADER)


def append_row(row):
    with open(OUTPUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(row)


def make_cache_key(strategy, hours, run):
    text = f"{strategy}-{hours}-{run}"
    return hashlib.md5(text.encode()).hexdigest()


def run_large_experiment():

    ensure_output()

    cache = load_cache()

    orchestrator = Orchestrator()

    total_runs = len(STRATEGIES) * len(WEEKLY_HOURS) * RUNS_PER_SETTING

    counter = 0

    print("Running large ML dataset experiment")
    print(f"Total runs: {total_runs}")

    for strategy in STRATEGIES:
        for hours in WEEKLY_HOURS:
            for run in range(RUNS_PER_SETTING):

                counter += 1

                cache_key = make_cache_key(strategy, hours, run)

                if cache_key in cache:
                    continue

                session_id = str(uuid.uuid4())

                state = SessionState(session_id=session_id)

                request_payload = {
                    "job_requirement": "Backend Developer",
                    "known_skills": [],
                    "weekly_time_hours": hours,
                    "strategy": strategy,
                    "request_type": "generate_plan_and_execute",
                    "start_date": datetime(2026, 1, 1),
                }

                print(f"[{counter}/{total_runs}] {strategy} | {hours}h | run {run+1}")

                orchestrator.handle_request(request_payload, state)

                completed, missed = simulate_lifecycle(
                    strategy,
                    session_id,
                    state,
                    orchestrator.monitor,
                    hours
                )

                orchestrator.monitor.collector.build_session_snapshot(
                    session_id=session_id,
                    weekly_hours_allocated=hours,
                    planned_days=5
                )

                metrics = orchestrator.monitor.get_session_metrics(session_id)

                row = [
                    session_id,
                    strategy,
                    hours,
                    len(state.execution_state.tasks),
                    completed,
                    missed,
                    metrics.completion_rate,
                    metrics.delay_index / 3600,
                    metrics.workload_utilization,
                    metrics.stability_score,
                    metrics.dropoff_risk_score,
                    metrics.consistency_score,
                ]

                append_row(row)

                save_cache(cache_key)


if __name__ == "__main__":
    run_large_experiment()