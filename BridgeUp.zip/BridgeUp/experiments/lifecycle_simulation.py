from typing import List
import random


def simulate_lifecycle(tasks, schedule_blocks, strategy, weekly_hours):
    """
    Deterministic simulation of user task completion behavior.

    Returns:
        completed_tasks (int)
        missed_tasks (int)
    """

    total_tasks = len(tasks)

    # -----------------------------------
    # Strategy behaviour models
    # -----------------------------------

    if strategy == "fast":
        completion_probability = 0.55

    elif strategy == "balanced":
        completion_probability = 0.75

    elif strategy == "deep":
        completion_probability = 0.65

    else:
        completion_probability = 0.6

    # Weekly hours influence engagement
    hour_modifier = weekly_hours / 15

    completion_probability *= hour_modifier

    completion_probability = min(max(completion_probability, 0.2), 0.95)

    completed = 0
    missed = 0

    random.seed(42)  # deterministic experiment behavior

    for _ in range(total_tasks):

        if random.random() < completion_probability:
            completed += 1
        else:
            missed += 1

    return completed, missed