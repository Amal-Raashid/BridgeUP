import time
from datetime import datetime

from agents.orchestrator_agent.orchestrator import Orchestrator
from agents.orchestrator_agent.state import SessionState

from integrations.resource_aggregator import ResourceAggregator
from agents.llm_agent.reasoning_engine import LLMReasoningEngine


def pause():
    time.sleep(1)


def section(title):
    print("\n--------------------------------")
    print(title)
    print("--------------------------------")


def show_resource(resource):

    title = None
    url = None

    if isinstance(resource, dict):
        title = resource.get("title") or resource.get("name")
        url = resource.get("url") or resource.get("html_url") or resource.get("link")

    else:
        title = getattr(resource, "title", None)
        url = getattr(resource, "url", None) or getattr(resource, "html_url", None)

    if title is None:
        title = str(resource)

    if url:
        print("-", title)
        print("   ", url)
    else:
        print("-", title)


def show_top(title, items):

    print(f"\nTop {title}:")

    if not items:
        print("No resources available")
        return

    for item in items[:3]:
        show_resource(item)


def run_demo():

    print("\n================================")
    print("BRIDGEUP HYBRID MULTI-AGENTIC AI ")
    print("================================\n")

    orchestrator = Orchestrator()
    state = SessionState()

    request = {
        "job_requirement": "Backend Developer",
        "known_skills": ["Python"],
        "weekly_time_hours": 10,
        "strategy": "balanced",
        "request_type": "generate_plan_and_execute",
        "start_date": datetime(2026, 3, 5)
    }

    print("User Goal:", request["job_requirement"])
    print("Known Skills:", ", ".join(request["known_skills"]))
    print("Weekly Study Time:", request["weekly_time_hours"], "hours")

    pause()

    response = orchestrator.handle_request(request, state)

    # ------------------------------------------------
    # ROADMAP
    # ------------------------------------------------

    section("1. Learning Roadmap Generated")

    roadmap = state.planning_state.roadmap_options.get(
        state.planning_state.selected_strategy
    )

    for step in roadmap.steps:
        print("-", step.skill_name)

    pause()

    # ------------------------------------------------
    # RESOURCE AGGREGATOR (REAL DATA)
    # ------------------------------------------------

    section("2. Learning Resources Retrieved")

    aggregator = ResourceAggregator()

    resources = aggregator.collect_by_role(request["job_requirement"])

    print("Jobs:", len(resources.jobs))
    print("Courses:", len(resources.courses))
    print("Projects:", len(resources.projects))
    print("Tutorials:", len(resources.tutorials))

    pause()

    # ------------------------------------------------
    # LLM RANKING
    # ------------------------------------------------

    section("3. Ranked Learning Resources")

    llm = LLMReasoningEngine()

    ranked = llm.rank_resources(resources)

    if isinstance(ranked, list):
        ranked = ranked[0]
    
    courses = ranked.ranked_courses or resources.courses
    projects = ranked.ranked_projects or resources.projects
    tutorials = ranked.ranked_tutorials or resources.tutorials
    jobs = ranked.ranked_jobs or resources.jobs

    show_top("Courses", courses)
    show_top("Projects", projects)
    show_top("Tutorials", tutorials)
    show_top("Jobs", jobs)

    pause()

    # ------------------------------------------------
    # LEARNING PLAN
    # ------------------------------------------------

    section("4. LLM Based Learning Plan")

    learning_plan = llm.generate_learning_plan(resources, ranked)

    if isinstance(learning_plan, list):
        learning_plan = learning_plan[0]

    print("\nSummary:\n")
    print(learning_plan.summary)

    print("\nLearning Phases:\n")

    for phase in learning_plan.learning_phases:
        print("-", phase.phase_name)

    pause()

    # ------------------------------------------------
    # TASKS
    # ------------------------------------------------

    section("5. Task Schedule")

    schedule = response.get("schedule")

    print("Total Tasks Generated:", len(schedule))

    print("\nExample Tasks:\n")

    for block in schedule[:5]:
        print("-", block.task_id)

    pause()

    print("\n--------------------------------")
    print("DEMO COMPLETE")
    print("--------------------------------\n")


if __name__ == "__main__":
    run_demo()