import csv
import statistics
from pathlib import Path
from collections import defaultdict


# ============================================================
# FILE PATHS
# ============================================================

INPUT_PATH = Path("paper_assets") / "03_metrics" / "metrics_phase3.csv"
OUTPUT_PATH = Path("paper_assets") / "03_metrics" / "metrics_phase3_summary.md"


# ============================================================
# EXPECTED CSV SCHEMA (Phase 3)
# ============================================================

EXPECTED_COLUMNS = [
    "session_id",
    "strategy",
    "weekly_hours",
    "total_tasks",
    "completed_tasks",
    "missed_tasks",
    "completion_rate",
    "delay_index_hours",
    "workload_utilization",
    "stability_score",
    "dropoff_risk",
    "consistency_score",
    "ranked_jobs",
    "ranked_courses",
    "ranked_projects",
    "ranked_tutorials",
]


# ============================================================
# METRICS USED FOR AGGREGATION
# (LLM columns are excluded from statistics)
# ============================================================

METRIC_COLUMNS = [
    "completion_rate",
    "delay_index_hours",
    "workload_utilization",
    "stability_score",
    "dropoff_risk",
    "consistency_score",
]


# ============================================================
# CSV LOADER
# ============================================================

def validate_schema(fieldnames):

    if fieldnames != EXPECTED_COLUMNS:
        raise ValueError(
            f"CSV schema mismatch.\nExpected:\n{EXPECTED_COLUMNS}\n\nGot:\n{fieldnames}"
        )


def load_data():

    with open(INPUT_PATH, "r", encoding="utf-8") as f:

        reader = csv.DictReader(f)

        validate_schema(reader.fieldnames)

        data = []

        for row in reader:

            parsed = {}

            for key, value in row.items():

                if key in ["session_id", "strategy"]:
                    parsed[key] = value

                else:
                    parsed[key] = float(value)

            data.append(parsed)

    return data


# ============================================================
# GROUP BY STRATEGY
# ============================================================

def group_by_strategy(data):

    grouped = defaultdict(list)

    for row in data:
        grouped[row["strategy"]].append(row)

    return grouped


# ============================================================
# COMPUTE MEAN + STD
# ============================================================

def compute_statistics(rows):

    results = {}

    for metric in METRIC_COLUMNS:

        values = [r[metric] for r in rows]

        mean = statistics.mean(values)

        if len(values) > 1:
            std = statistics.stdev(values)
        else:
            std = 0.0

        results[metric] = (mean, std)

    return results


# ============================================================
# MARKDOWN REPORT
# ============================================================

def generate_markdown(grouped):

    lines = []

    lines.append("# BridgeUp Phase 3 Metrics Summary\n")

    for strategy, rows in grouped.items():

        lines.append(f"## Strategy: {strategy}\n")

        stats = compute_statistics(rows)

        lines.append("| Metric | Mean | Std |")
        lines.append("|-------|------|-----|")

        for metric, (mean, std) in stats.items():
            lines.append(f"| {metric} | {mean:.3f} | {std:.3f} |")

        lines.append("\n")

    return "\n".join(lines)


# ============================================================
# MAIN
# ============================================================

def main():

    print("Loading experiment data...")

    data = load_data()

    grouped = group_by_strategy(data)

    markdown = generate_markdown(grouped)

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(markdown)

    print("Summary generated:")
    print(OUTPUT_PATH)


if __name__ == "__main__":
    main()