import csv
import uuid
import shutil
from pathlib import Path
from datetime import datetime

from agents.orchestrator_agent.orchestrator import Orchestrator
from agents.orchestrator_agent.state import SessionState

from experiments.run_phase2_5 import simulate_lifecycle


# ============================================================
# Experiment Configuration
# ============================================================

STRATEGIES = ["fast", "balanced", "deep"]
WEEKLY_HOURS = [5, 10, 15]

RUNS_PER_SETTING = 2

DEMO_MODE = True
if DEMO_MODE:
    RUNS_PER_SETTING = 1


OUTPUT_PATH = Path("paper_assets") / "03_metrics" / "metrics_phase3.csv"


CSV_HEADER = [
    "session_id",
    "strategy",
    "weekly_hours",
    "total_tasks",
    "completed_tasks",
    "missed_tasks",
    "completion_rate",
    "delay_index_hours",
    "workload_utilization",
    "stability_score",
    "dropoff_risk",
    "consistency_score",
    "ranked_jobs",
    "ranked_courses",
    "ranked_projects",
    "ranked_tutorials",
]


# ============================================================
# Monitoring Cleanup
# ============================================================

def clear_monitoring_sessions():
    base = Path("data/monitoring_logs") / "sessions"
    if base.exists():
        shutil.rmtree(base)


# ============================================================
# CSV Utilities
# ============================================================

def ensure_output_directory():
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)


def write_header():
    with open(OUTPUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(CSV_HEADER)


def append_row(row):
    with open(OUTPUT_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(row)


# ============================================================
# Experiment Runner
# ============================================================

def run_experiments():

    ensure_output_directory()
    write_header()
    clear_monitoring_sessions()

    orchestrator = Orchestrator()

    total_runs = len(STRATEGIES) * len(WEEKLY_HOURS) * RUNS_PER_SETTING
    counter = 0

    print("=== Phase 3 Evaluation ===")
    print(f"Total runs: {total_runs}")
    print("--------------------------------")

    for strategy in STRATEGIES:
        for hours in WEEKLY_HOURS:
            for run in range(RUNS_PER_SETTING):

                counter += 1
                session_id = str(uuid.uuid4())

                state = SessionState(session_id=session_id)

                request_payload = {
                    "job_requirement": "Backend Developer",
                    "known_skills": [],
                    "weekly_time_hours": hours,
                    "strategy": strategy,
                    "request_type": "generate_plan_and_execute",
                    "start_date": datetime(2026, 1, 1),
                }

                print(f"[{counter}/{total_runs}] {strategy} | {hours}h | run {run+1}")

                orchestrator.handle_request(request_payload, state)

                # --------------------------------------------------
                # Simulate user behavior
                # --------------------------------------------------

                completed, missed = simulate_lifecycle(
                    strategy,
                    session_id,
                    state,
                    orchestrator.monitor,
                    hours
                )

                # --------------------------------------------------
                # Build monitoring snapshot
                # --------------------------------------------------

                orchestrator.monitor.collector.build_session_snapshot(
                    session_id=session_id,
                    weekly_hours_allocated=hours,
                    planned_days=5
                )

                metrics = orchestrator.monitor.get_session_metrics(session_id)

                # --------------------------------------------------
                # Extract LLM resource counts
                # --------------------------------------------------

                ranked_jobs = 0
                ranked_courses = 0
                ranked_projects = 0
                ranked_tutorials = 0

                if state.llm_ranked_resources:

                    rr = state.llm_ranked_resources[0]

                    ranked_jobs = len(rr.ranked_jobs)
                    ranked_courses = len(rr.ranked_courses)
                    ranked_projects = len(rr.ranked_projects)
                    ranked_tutorials = len(rr.ranked_tutorials)

                # --------------------------------------------------
                # Write experiment row
                # --------------------------------------------------

                row = [
                    session_id,
                    strategy,
                    hours,
                    len(state.execution_state.tasks),
                    completed,
                    missed,
                    metrics.completion_rate,
                    metrics.delay_index / 3600,
                    metrics.workload_utilization,
                    metrics.stability_score,
                    metrics.dropoff_risk_score,
                    metrics.consistency_score,
                    ranked_jobs,
                    ranked_courses,
                    ranked_projects,
                    ranked_tutorials,
                ]

                append_row(row)

    print("--------------------------------")
    print("Phase 3 evaluation complete.")
    print(f"Saved to: {OUTPUT_PATH}")


if __name__ == "__main__":
    run_experiments()