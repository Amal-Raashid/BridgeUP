# BridgeUp Phase 2.5 Metrics Summary

Aggregated per-strategy mean and population standard deviation.

## Strategy: balanced

| Metric | Mean | Std |
|--------|------|-----|
| completion_rate | 0.846154 | 0.000000 |
| delay_index_hours | 0.000000 | 0.000000 |
| workload_utilization | 2.000000 | 0.000000 |
| stability_score | 0.666675 | 0.471393 |
| dropoff_risk | 0.153846 | 0.000000 |
| consistency_score | 1.000000 | 0.000000 |

## Strategy: deep

| Metric | Mean | Std |
|--------|------|-----|
| completion_rate | 0.692308 | 0.000000 |
| delay_index_hours | 6.000000 | 0.000000 |
| workload_utilization | 2.000000 | 0.000000 |
| stability_score | 0.666675 | 0.471393 |
| dropoff_risk | 0.307692 | 0.000000 |
| consistency_score | 1.000000 | 0.000000 |

## Strategy: fast

| Metric | Mean | Std |
|--------|------|-----|
| completion_rate | 0.538462 | 0.000000 |
| delay_index_hours | 0.000000 | 0.000000 |
| workload_utilization | 1.566667 | 0.612826 |
| stability_score | 0.666675 | 0.471392 |
| dropoff_risk | 0.461538 | 0.000000 |
| consistency_score | 1.000000 | 0.000000 |

