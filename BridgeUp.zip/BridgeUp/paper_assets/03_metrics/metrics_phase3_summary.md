# BridgeUp Phase 3 Metrics Summary

## Strategy: fast

| Metric | Mean | Std |
|-------|------|-----|
| completion_rate | 0.538 | 0.000 |
| delay_index_hours | 0.000 | 0.000 |
| workload_utilization | 1.567 | 0.751 |
| stability_score | 0.667 | 0.577 |
| dropoff_risk | 0.462 | 0.000 |
| consistency_score | 1.000 | 0.000 |


## Strategy: balanced

| Metric | Mean | Std |
|-------|------|-----|
| completion_rate | 0.846 | 0.000 |
| delay_index_hours | 0.000 | 0.000 |
| workload_utilization | 2.000 | 0.000 |
| stability_score | 0.667 | 0.577 |
| dropoff_risk | 0.154 | 0.000 |
| consistency_score | 1.000 | 0.000 |


## Strategy: deep

| Metric | Mean | Std |
|-------|------|-----|
| completion_rate | 0.692 | 0.000 |
| delay_index_hours | 6.000 | 0.000 |
| workload_utilization | 2.000 | 0.000 |
| stability_score | 0.667 | 0.577 |
| dropoff_risk | 0.308 | 0.000 |
| consistency_score | 1.000 | 0.000 |

