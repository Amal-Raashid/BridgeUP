Below is a **machine-oriented, highly structured Markdown file** you can upload directly into the new Paper Chat.
It is written *for a model* (ChatGPT) to consume as authoritative context — not for human reading. Use the filename:

**`BridgeUp_Master_Context_for_Paper.md`**

Paste the entire contents below into the new chat as a single file upload / message. The chat should treat this as *the single source of truth* for the BridgeUp project when drafting the paper.

---

# BridgeUp — Master Context for Paper-writing Assistant

**Filename:** `BridgeUp_Master_Context_for_Paper.md`
**Purpose:** authoritative machine-readable context for generating an IEEE-style paper. Use this file as *only* context; do not invent facts. If a fact is missing, ask for the exact artifact (file path / CSV / log).

---

## 0. Ground rules for the assistant consuming this file

1. **Do not hallucinate.** If a required number / figure / CSV is missing, ask the user to upload it.
2. **Do not add new experiments or claim results** unless they are present in `paper_assets/03_metrics/` or in `data/events/` / `data/monitoring_logs/`.
3. **Follow IEEE style**: concise abstract, structured sections, figures/tables numbered, captions, references. Use formal academic tone.
4. **Cite artifacts by path** in the paper when referencing data (e.g., `data/events/session_abc.jsonl`, `paper_assets/03_metrics/metrics_v1.csv`).
5. **If a value is needed and not present, ask for it** (exact file name / CSV row / plot).

---

## 1. Project snapshot (authoritative)

* **Project name:** BridgeUp
* **Version for paper:** `bridgeup-paper-v1` (tag in git).
* **Implemented modules:** Planning Agent, Action Agent, Orchestrator, Monitoring Agent, Unified Event System, Data Collector (D1–D4).
* **System claim for paper:** Deterministic, replayable, observable multi-agent orchestration for personalized learning (Phase 2.5). No adaptation or ML used in v1.

---

## 2. Repo layout (exact paths)

```
BridgeUp/
├── agents/
│   ├── planning_agent/
│   │   ├── models.py
│   │   ├── planner.py
│   │   └── __init__.py
│   ├── action_agent/
│   │   ├── models.py
│   │   ├── scheduler.py
│   │   ├── executor.py
│   │   ├── tracker.py
│   │   └── __init__.py
│   ├── orchestrator_agent/
│   │   └── orchestrator.py
│   └── monitoring_agent/
│       ├── collector.py
│       ├── metrics.py
│       ├── analyzer.py
│       └── __init__.py
|
├── events/
│   ├── schema.py
│   ├── emitter.py
│   ├── logger.py
│   └── validator.py
|
├── data/
│   ├── processed/
│   │   ├── D1_final.csv
│   │   ├── D2_skill_domain_taxonomy.csv
│   │   ├── D3_skill_job_mapping.csv
│   │   └── D4_skill_prerequisites.csv
│   ├── events/                 # JSONL per session
│   │   └── session_<session_id>.jsonl
│   └── monitoring_logs/
│       └── sessions/{session_id}/
│           ├── tasks.json
│           └── session_snapshots.json
|
├── experiments/
│   └── run_phase2_5.py
|
├── paper_assets/
│   ├── 01_system_report.md
│   ├── 02_agent_reports/
│   ├── 03_metrics/
│   │   └── metrics_v1.csv
│   ├── 04_diagrams/
│   │   └── architecture.png
│   └── 05_experiments/
└── tests/
```

---

## 3. Authoritative datasets (D1–D4)

* **D1 (Learning Resources):** `data/processed/D1_final.csv`
  Columns: `resource_id, title, provider, domain, skill_tags, difficulty, duration_hours, cost_type, url`
  ~120 curated resources.
* **D2 (Skill Taxonomy):** `data/processed/D2_skill_domain_taxonomy.csv`
  Columns: `skill_id, skill_name, domain, parent_skill, level, description`
* **D3 (Skill→Job Mapping):** `data/processed/D3_skill_job_mapping.csv`
  Columns: `job_role_id, job_role_name, required_skills, skill_weightage, domain` (skill_weightage sums to 1.0 per role).
* **D4 (Prerequisites):** `data/processed/D4_skill_prerequisites.csv`
  Columns: `skill_id, prerequisite_skill_id, dependency_type` where `dependency_type ∈ {hard, soft}`.

**Note:** These datasets are frozen and authoritative for the paper.

---

## 4. Event system (schema & usage) — exact spec

**File:** `events/schema.py` (authoritative). Use the following minimal event specification when analyzing logs.

**EventType** (string enum):

```
SESSION_STARTED
PLAN_READY
EXECUTION_STARTED
TASK_CREATED
TASK_STARTED
TASK_COMPLETED
TASK_MISSED
TASK_RESCHEDULED
SESSION_ENDED
ERROR
METRICS_COMPUTED   # optional
```

**Event (JSON) — required keys**

```json
{
  "event_id": "uuid4-string",
  "version": "1.0",
  "timestamp": "YYYY-MM-DDTHH:MM:SSZ",   // UTC ISO-8601
  "session_id": "session_<id>",
  "agent": "orchestrator" | "action" | "monitoring",
  "event_type": "TASK_STARTED",
  "payload": { /* domain-specific */ },
  "metadata": { /* optional context */ }
}
```

**Example event line (JSONL):**

```json
{"event_id":"550e8400-e29b-41d4-a716-446655440000","version":"1.0","timestamp":"2026-02-20T10:00:00Z","session_id":"session_abc123","agent":"action","event_type":"TASK_STARTED","payload":{"task_id":"task_001","skill_id":"skill_html","scheduled_start":"2026-02-20T09:00:00Z"},"metadata":{"node":"executor-v1"}}
```

**Storage:** append-only JSONL: `data/events/session_<session_id>.jsonl`

**Emitter API (agents use this):**

```py
emit_event(event_type: str, session_id: str, agent: str, payload: dict, metadata: dict=None) -> None
```

* `emit_event` validates the event against schema, injects `event_id` & `timestamp`, then appends to the session JSONL via `events/logger.py`. The paper must reference `events/emitter.py` as the only allowed emitter.

---

## 5. Public interfaces (what the paper may reference — signatures are authoritative)

### Planning Agent

* `generate_multiple_learning_plans(job_requirement: dict, known_skills: List[str], weekly_time_hours: float) -> Dict[str, LearningRoadmap]`

  * Returns keys: `"fast"`, `"balanced"`, `"deep"`.
* `schedule_roadmap_weekwise(learning_roadmap: LearningRoadmap) -> List[WeeklyPlan]`

### Action Agent

* `tasks = action_agent.generate_tasks(learning_roadmap: LearningRoadmap, weekly_time_hours: float) -> List[Task]`
* `action_agent.start_execution(session_id: str, tasks: List[Task]) -> ExecutionHandle`
  Action Agent uses `emit_event` to log TASK_* events; task lifecycle is deterministic.

### Orchestrator

* `orchestrator.generate_plan_and_execute(user_profile: dict) -> { "session_id": <id>, "status": "EXECUTION_ACTIVE", "plans": {...} }`
  Orchestrator calls Planning Agent, then Action Agent, emits lifecycle events, instantiates MonitoringAgent for the session.

### Monitoring Agent

* `get_session_metrics(session_id: str) -> MetricSnapshot`
* `get_risk_profile(session_id: str) -> RiskProfile`
* `collect_task_event(event: dict) -> None`  # internal usage by collector

All functions above are **deterministic**: given the same inputs they return the same outputs.

---

## 6. Monitoring metrics — exact formulas (authoritative)

When drafting the Results, use these formulas and reference `agents/monitoring_agent/metrics.py`.

* **Completion Rate (CR)**
  `CR = completed_tasks / total_tasks` (per session)

* **Delay Index (DI)**
  `DI = mean(max(0, actual_finish_time - deadline_time))` expressed in hours (session-level average)

* **Workload Utilization (WU)**
  `WU = used_hours / allocated_hours` (0..1)

* **Stability Score (SS)**
  `SS = 1 / (1 + stddev(task_intervals_in_days))`  // higher is more stable

* **Dropoff Risk (DR)**
  `DR = missed_tasks / total_tasks` (same as 1 - CR but computed separately to capture mechanism differences)

* **Consistency Score (CS)**
  `CS = active_days / planned_days`

**Note:** All metric computations run over the monitoring logs under `data/monitoring_logs/sessions/{session_id}/`.

---

## 7. Experiments — reproducible run (how to reproduce)

**Script:** `experiments/run_phase2_5.py` (authoritative). The Paper Chat should call this script or ask for its output if numbers are needed.

**Typical command:**

```bash
python experiments/run_phase2_5.py --n_sessions 30 --strategies fast,balanced,deep --weekly_hours 5,10,15 --out metrics_v1.csv
```

**Expected outputs** (place under `paper_assets/03_metrics/`):

* `metrics_v1.csv` with the columns:

```
session_id, strategy, weekly_hours, total_tasks, completed_tasks, missed_tasks, completion_rate, delay_index_hours, workload_utilization, stability_score, dropoff_risk, consistency_score
```

**To generate plots** (standard names):

* `fig_completion_rate_vs_hours.png`
* `fig_delay_index_histogram.png`
* `fig_utilization_boxplot.png`
* `fig_stability_vs_strategy.png`

If these files are missing, the Paper Chat must request `metrics_v1.csv` or the raw JSONL logs for the specified sessions.

---

## 8. Figures & tables required in paper (explicit)

When drafting the paper include placeholders and captions for the following artifacts. If any file is missing ask for it.

* **Figure 1:** System architecture (file: `paper_assets/04_diagrams/architecture.png`) — caption: “BridgeUp architecture: Orchestrator, Planning, Action, Monitoring, Event system.”
* **Figure 2:** Example event timeline for a single session (derived from `data/events/session_<id>.jsonl`) — caption: “Append-only event timeline for session `<id>`.”
* **Figure 3:** Completion rate vs weekly hours (png above).
* **Figure 4:** Delay index distribution (histogram).
* **Table 1:** Dataset summary (rows: D1–D4, cols: size, fields, source). Use `data/processed/*` to fill numbers.
* **Table 2:** Comparison table (Coursera / Udemy / SWAYAM / BridgeUp) — include checkboxes for: personalized path, time-awareness, constraint-based planning, adaptation (no), event observability (yes for BridgeUp).
* **Table 3:** Metrics summary (aggregated statistics across sessions) — load from `paper_assets/03_metrics/metrics_v1.csv`.

---

## 9. Paper section mapping (what to draft from which artifact)

Map each paper section to the artifacts below. If any artifact is missing, ask for it.

* **Abstract:** summary of contributions (one-paragraph) — based on this file + experiments summary.
* **Introduction:** problem statement + brief contributions — use `01_system_report.md`.
* **Related Work:** the chat should produce a neutral short paragraph comparing recommendation systems vs schedule-aware planning. (If external citations required, ask user to provide them.)
* **System Architecture (Methods):** translate `agents/*` reports & `events/schema.py` into the architecture description. Include Figure 1.
* **Planning Agent (Methods):** use `agents/planning_agent` report — include algorithms & deterministic guarantees.
* **Execution & Action Agent (Methods):** use `agents/action_agent` report.
* **Monitoring & Metrics (Methods):** use `agents/monitoring_agent` report and the exact metric formulas above.
* **Experiments (Setup):** describe `experiments/run_phase2_5.py`, number of simulated sessions, strategy variations, and which `metrics_v1.csv` was produced.
* **Results:** produce tables/plots from `paper_assets/03_metrics/metrics_v1.csv` and `data/events/` as necessary.
* **Limitations:** use the explicit list from Section 8 of this file.
* **Future Work:** use the roadmap in the repo and this file’s Phase 3 notes.
* **Conclusion & Acknowledgements:** short summary + contributor names.

---

## 10. Writing constraints and safety (explicit instructions to the assistant)

* **Do not claim adaptation, ML, or LLM usage** in v1. Use language: “planned for Phase 3”.
* **When citing numbers, reference the exact file path** in the sentence. Example: “As shown in `paper_assets/03_metrics/metrics_v1.csv`, the mean completion rate for 10 hours/week is 0.72.” (Do not invent numbers).
* **Do not include external citations** unless user uploads the citation list. Ask for bibliography file if needed.
* **Keep claims conservative**: use “demonstrates potential” rather than “proves” for generalization statements.

---

## 11. Checklist the assistant must follow when producing the first draft

1. Confirm presence of the following files:

   * `paper_assets/03_metrics/metrics_v1.csv`
   * `paper_assets/04_diagrams/architecture.png`
   * At least 3 session logs in `data/events/` (ask which session ids to use).
2. If any file is missing, request upload explicitly.
3. Produce a paper outline with section titles (IEEE) and a one-paragraph content plan per section.
4. After outline approved, produce full draft for Introduction + Methods + Experiments.
5. Produce Results section only after confirming `metrics_v1.csv` presence.
6. Provide figure captions and table captions in the draft with embedded file path references.
7. Provide an appendix listing commands used to reproduce experiments.

---

## 12. Appendix: sample JSON / CSV formats (authoritative examples)

**Sample event line** (already shown above).

**Sample metrics CSV row**

```
session_id,strategy,weekly_hours,total_tasks,completed_tasks,missed_tasks,completion_rate,delay_index_hours,workload_utilization,stability_score,dropoff_risk,consistency_score
session_001,balanced,10,20,16,4,0.80,2.4,0.85,0.92,0.20,0.90
```

**Sample Task JSON (stored under monitoring logs `tasks.json`):**

```json
[
  {
    "task_id": "task_001",
    "skill_id": "skill_html",
    "scheduled_start": "2026-02-20T09:00:00Z",
    "deadline": "2026-02-20T11:00:00Z",
    "started_at": "2026-02-20T09:05:00Z",
    "completed_at": "2026-02-20T10:30:00Z",
    "status": "completed",
    "duration_hours": 1.5
  }
]
```

---

## 13. If the assistant needs clarifications / missing artifacts, request EXACTLY these items

* `paper_assets/03_metrics/metrics_v1.csv` (full path) — required for Results.
* `paper_assets/04_diagrams/architecture.png` (high-res) — required for System Architecture figure.
* At least 3 event logs: `data/events/session_<id>.jsonl` (indicate which `<id>` you want).
* `data/processed/D1_final.csv` (if Table 1 numbers are required).
* `paper_assets/02_agent_reports/*` (if deeper technical wording is required).

Always request file names and prefer zipped folder uploads when multiple files are needed.

---

## 14. Final instructions to the Paper Chat (one-paragraph)

You are provided with a complete, authoritative machine-readable context for BridgeUp (Phase 2.5). Use **only** files present in the repository and `paper_assets/` to draft the paper. If data or plots are missing, pause and ask for the exact file path. Comply with the writing constraints in Section 10. Produce an IEEE-style outline; on approval produce full draft sections incrementally (Introduction → Methods → Experiments → Results → Discussion → Conclusion). Reference files by path and include figure/table captions that point to the source artifact.

---

### End of `BridgeUp_Master_Context_for_Paper.md`

Paste this file into the Paper Chat as the authoritative context. I will help you iterate on the draft output the Paper Chat produces.
