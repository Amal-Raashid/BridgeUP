```markdown
# BridgeUp_Planning_Agent_Report.md

---

# 1. Module Overview

## Purpose of this Agent

The Planning Agent is a deterministic, constraint-aware learning roadmap generator within the BridgeUp system. Its primary responsibility is to translate structured job-role requirements and curated skill datasets into an ordered, time-bounded learning roadmap.

It performs:

- Skill gap identification
- Dependency-aware skill sequencing
- Resource selection
- Mastery-level depth assignment
- Strategy-based plan generation (FAST / BALANCED / DEEP)
- Weekly time allocation scheduling
- Structured explainability generation

It does not perform monitoring, adaptation, persistence, or learning from user behavior.

---

## Role in BridgeUp Architecture

The Planning Agent acts as a pure computational module. It receives fully prepared data objects and produces structured planning artifacts. It does not access storage, perform I/O, or maintain state.

It is designed to be:

- Stateless
- Deterministic
- Reproducible
- Dependency-injected

---

## Phase Classification

Phase: Static Deterministic Planning Engine

The module represents a fully functional static planner. It does not implement adaptive or feedback-driven planning.

---

## Design Philosophy

- Strict separation between data and logic
- Deterministic output for identical inputs
- Explicit constraint enforcement
- Transparent ordering rules
- Modular structure
- Strategy-based extensibility without randomness

---

# 2. Position in System Architecture

## Upstream Dependencies

The Planning Agent requires:

- `JobSkillRequirement`
- `Skill`
- `SkillPrerequisite`
- `LearningResource`
- User known skills
- Weekly time budget

All inputs are injected externally.

---

## Downstream Consumers

The Planning Agent produces:

- `LearningRoadmap`
- `WeeklyPlan`
- Strategy variants
- `ExplainabilityNote`

These outputs are consumed by orchestration or presentation layers.

---

## Interaction with Other Agents

The module does not invoke other agents. It operates as a pure computation engine and is designed to be called by an external coordinator.

---

## Invocation Flow

1. External module loads datasets.
2. External module constructs dataclass objects.
3. External module calls:
   - `generate_learning_roadmap()` or
   - `generate_multiple_learning_plans()`
4. Planning Agent returns structured outputs.

---

# 3. Directory & File Structure

```

agents/
└── planning_agent/
├── models.py
├── planner.py
└── **init**.py

````

---

## models.py

Defines:

- Dataset-level dataclasses
- Internal planning models
- Enumerations (MasteryLevel, PlanStrategy)

No business logic is present.

---

## planner.py

Contains:

- Validation helpers
- Skill gap computation
- Dependency graph construction
- Skill ordering logic
- Resource selection
- Mastery logic
- Roadmap assembly
- Strategy-based generation
- Weekly scheduling
- Explainability generation

All logic resides in this file.

---

## __init__.py

Module exposure file. No internal logic.

---

# 4. Core Data Models

## Dataset Models

### Skill
| Field | Type |
|--------|------|
| skill_id | str |
| skill_name | str |
| domain | str |
| parent_skill | Optional[str] |
| level | int |
| description | str |

---

### LearningResource
| Field | Type |
|--------|------|
| resource_id | str |
| title | str |
| provider | str |
| domain | str |
| skill_tags | List[str] |
| difficulty | str |
| duration_hours | float |
| cost_type | str |
| url | str |

---

### SkillPrerequisite
| Field | Type |
|--------|------|
| skill_id | str |
| prerequisite_skill_id | str |
| dependency_type | str |

---

### JobSkillRequirement
| Field | Type |
|--------|------|
| job_role_id | str |
| job_role_name | str |
| required_skills | List[str] |
| skill_weightage | List[float] |
| domain | str |

---

## Internal Planning Models

### SkillNode
Internal graph representation.

### ResourceAssignment
Maps a resource to a specific skill.

### MasteryLevel (Enum)
- HIGH
- MEDIUM
- LOW

### PlanStrategy (Enum)
- FAST
- BALANCED
- DEEP

### RoadmapStep
Represents one skill unit in roadmap.

### LearningRoadmap
Represents complete structured plan.

### WeeklyPlan
Represents week-level time allocation.

### ExplainabilityNote
Structured reasoning container.

---

# 5. Public Interfaces

## Single Plan Generation

```python
generate_learning_roadmap(
    *,
    job_requirement,
    known_skills: List[str],
    all_skills: Dict[str, Skill],
    prerequisites: List[SkillPrerequisite],
    resources: List[LearningResource],
    weekly_time_hours: float,
    strategy: PlanStrategy = PlanStrategy.BALANCED,
) -> LearningRoadmap
````

---

## Multiple Plan Generation

```python
generate_multiple_learning_plans(
    *,
    job_requirement,
    known_skills,
    all_skills,
    prerequisites,
    resources,
    weekly_time_hours,
) -> Dict[str, LearningRoadmap]
```

Returns:

```
{
  "fast": LearningRoadmap,
  "balanced": LearningRoadmap,
  "deep": LearningRoadmap
}
```

---

## Weekly Scheduling

```python
schedule_roadmap_weekwise(
    roadmap: LearningRoadmap
) -> List[WeeklyPlan]
```

---

## Explainability

```python
generate_explainability_notes(
    ordered_skills: List[str],
    skill_graph: Dict[str, SkillNode]
) -> List[ExplainabilityNote]
```

---

## Error Handling

* Empty required skills → ValueError
* Negative weekly hours → ValueError
* Dependency cycle → ValueError

No silent failures.

---

# 6. Internal Workflow

1. Validate inputs
2. Compute skill gaps
3. Build dependency graph
4. Order skills with constraints
5. Select matching resources
6. Determine mastery depth
7. Scale hours by mastery
8. Assemble roadmap
9. Optionally generate weekly plan
10. Optionally generate explainability

---

# 7. Algorithms & Logic

## Skill Gap Logic

Set difference between required and known skills.

---

## Dependency Handling

Hard prerequisites:

* Must be completed first

Soft prerequisites:

* Influence priority ordering

---

## Ordering Strategy

Deterministic loop:

1. Select skills whose hard prerequisites are satisfied
2. Sort by:

   * Descending weight
   * Fewest soft violations
3. Select first

Cycle detection included.

---

## Mastery Strategy

Coverage ratios:

| Level  | Coverage |
| ------ | -------- |
| HIGH   | 100%     |
| MEDIUM | 70%      |
| LOW    | 40%      |

Strategy behavior modifies mastery thresholds.

---

## Determinism Strategy

* Explicit sorting
* No randomness
* No time-based operations
* No hash-order dependence

---

# 8. Integration Points

The module exposes pure functions.

It integrates via:

* Direct function calls
* Dependency injection
* Structured dataclass inputs

No internal event system integration.
No logging framework usage.
No monitoring hooks.

---

# 9. Logging & Observability

Current implementation:

* No internal logging
* No event emission
* No metrics collection

Failures propagate via exceptions.

---

# 10. Determinism & Reliability Guarantees

* Same inputs → same output
* Stateless execution
* Replayable
* Idempotent
* No external side effects

---

# 11. Configuration & Extensibility

Tunable parameters:

* Mastery coverage ratios
* Strategy thresholds
* Ordering priority rules

Extension points:

* Replace mastery logic
* Replace resource selection heuristic
* Add advanced optimization layer

Versioning: implicit via code revision.

---

# 12. Current Limitations

* No adaptive replanning
* No feedback integration
* No parallel skill batching
* No critical path optimization
* No strict global time minimization
* No probabilistic ranking
* No dataset loading layer

---

# 13. Future Extensions

* Adaptive replanning engine
* Feedback-aware mastery updates
* Critical path compression
* Resource coverage minimization
* Event-based orchestration integration
* Parallelizable skill grouping
* Advanced optimization heuristics

---

# 14. Usage Example

## Invocation

```python
plans = generate_multiple_learning_plans(
    job_requirement=job_requirement,
    known_skills=["python"],
    all_skills=all_skills,
    prerequisites=prerequisites,
    resources=resources,
    weekly_time_hours=10,
)
```

---

## Sample Output Structure

```python
{
  "fast": LearningRoadmap(...),
  "balanced": LearningRoadmap(...),
  "deep": LearningRoadmap(...)
}
```

---

## Weekly Plan

```python
weekly_plan = schedule_roadmap_weekwise(plans["balanced"])
```

---

# 15. Summary

The Planning Agent is a deterministic, constraint-aware roadmap generation module.

It provides:

* Structured learning sequencing
* Strategy-based depth control
* Dependency enforcement
* Resource selection
* Weekly scheduling
* Explainability metadata

It is stable, modular, and suitable for publication as a static planning engine within a multi-agent architecture.

The implementation is reproducible, deterministic, and formally structured.

```
```
