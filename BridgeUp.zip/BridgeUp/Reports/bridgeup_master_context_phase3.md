# BridgeUp System Master Context
Version: Phase 3
Purpose: Provide authoritative technical context for AI-assisted academic paper writing.

This document consolidates system architecture, dataset design, experimentation pipeline, and machine learning extensions implemented in the BridgeUp platform.

The document is intended for automated paper-writing assistants and should be treated as the ground truth reference for the system.

---

# 1 System Overview

BridgeUp is a constraint-aware learning orchestration system designed to convert structured skill requirements into executable learning pathways.

The system uses a modular multi-agent architecture composed of specialized components responsible for planning, execution, monitoring, and orchestration.

The system emphasizes:

deterministic planning  
explicit constraint enforcement  
execution observability  
reproducible experimentation  

Phase 3 extends the architecture by introducing a predictive analytics layer capable of estimating learner dropout risk using monitoring metrics.

---

# 2 Architectural Layers

BridgeUp is organized into five layers.

Data Layer  
Planning Layer  
Execution Layer  
Monitoring Layer  
Observability Layer  

These layers are coordinated by the Orchestrator Agent.

---

# 3 Data Layer

The system relies on four curated datasets.

## D1 Learning Resources

Fields:

resource_id  
title  
provider  
domain  
skill_tags  
difficulty  
duration_hours  
cost_type  
url  

Represents structured learning materials.

---

## D2 Skill Taxonomy

Fields:

skill_id  
skill_name  
domain  
parent_skill  
level  
description  

Defines the canonical skill ontology used for planning.

---

## D3 Job Skill Mapping

Fields:

job_role_id  
job_role_name  
required_skills  
skill_weightage  
domain  

Defines role requirements used for skill gap computation.

---

## D4 Skill Prerequisite Graph

Fields:

skill_id  
prerequisite_skill_id  
dependency_type  

dependency_type ∈ {hard, soft}

Hard prerequisites enforce strict ordering constraints.

Soft prerequisites influence prioritization.

---

# 4 Agent Architecture

BridgeUp uses four specialized agents.

Planning Agent  
Action Agent  
Monitoring Agent  
Orchestrator Agent

Each agent operates independently but interacts through structured interfaces.

---

# 5 Planning Agent

Responsibilities:

skill gap detection  
dependency graph construction  
resource selection  
mastery depth allocation  
roadmap generation  

Inputs:

target job role  
known skills  
weekly study capacity  

Outputs:

LearningRoadmap object containing ordered skills and resources.

Strategies supported:

FAST  
BALANCED  
DEEP  

Planning logic is deterministic and rule-based.

---

# 6 Action Agent

Responsibilities:

roadmap-to-task transformation  
task scheduling  
deadline assignment  
execution tracking  

The Action Agent converts roadmap steps into executable tasks using a fixed-capacity scheduling model.

Scheduling model:

weekly time treated as hard constraint  
tasks distributed sequentially across study days  

Outputs:

task list  
schedule blocks  

---

# 7 Monitoring Agent

The Monitoring Agent aggregates task lifecycle signals and computes execution metrics.

Events processed:

TASK_CREATED  
TASK_STARTED  
TASK_COMPLETED  
TASK_MISSED  

Persistent task state is stored in:

tasks.json

Snapshots generated in:

session_snapshots.json

Metrics computed:

completion_rate  
delay_index  
workload_utilization  
stability_score  
dropoff_risk  
consistency_score  

Metrics are computed deterministically from execution data.

---

# 8 Orchestrator Agent

The Orchestrator coordinates the lifecycle of learning sessions.

Responsibilities:

workflow routing  
agent invocation  
state transition management  

Session lifecycle states:

INITIALIZED  
PLAN_READY  
EXECUTION_ACTIVE  
SESSION_COMPLETE  

The orchestrator ensures controlled communication between agents.

---

# 9 Event System

BridgeUp includes a unified event infrastructure.

Event properties:

append-only  
timestamped  
JSONL storage  

Event types:

SESSION_STARTED  
PLAN_READY  
EXECUTION_STARTED  
TASK_CREATED  
TASK_STARTED  
TASK_COMPLETED  
TASK_MISSED  

Event logs allow complete reconstruction of session execution.

---

# 10 Experimental Pipeline

Experiments are executed using:

experiments/run_phase2_5.py

Configuration parameters:

strategies:
FAST  
BALANCED  
DEEP  

weekly study capacity:
5 hours  
10 hours  
15 hours  

Runs per configuration:
10

Total sessions executed:

90

Lifecycle simulation generates behavior traces which are processed by the Monitoring Agent.

Output dataset:

paper_assets/03_metrics/metrics_v1.csv

Each row represents a learning session.

---

# 11 Monitoring Dataset Schema

metrics_v1.csv fields:

session_id  
strategy  
weekly_hours  
total_tasks  
completed_tasks  
missed_tasks  
completion_rate  
delay_index_hours  
workload_utilization  
stability_score  
dropoff_risk  
consistency_score  

This dataset forms the basis for predictive modeling.

---

# 12 Machine Learning Module (Phase 3)

Phase 3 introduces a predictive analytics module.

Objective:

predict learner dropout risk based on monitoring metrics.

The ML module operates independently from the orchestration pipeline.

---

# 13 ML Dataset Preparation

Script:

ml/build_ml_dataset.py

Transforms monitoring dataset into supervised learning dataset.

Target label:

dropout_label = (dropoff_risk >= 0.3)

Output file:

metrics_ml_ready.csv

Features:

strategy  
weekly_hours  
delay_index_hours  
workload_utilization  
stability_score  
consistency_score  

Engineered features:

delay_workload  
stability_consistency

---

# 14 Machine Learning Models

Three models were implemented.

Logistic Regression  
Random Forest  
XGBoost

Purpose:

predict learner dropout risk.

Training implemented in:

ml/train_model.py

Preprocessing:

StandardScaler

Train-test split:

80/20

random_state = 42

---

# 15 Model Evaluation

Evaluation performed using stratified cross validation.

Metrics reported:

accuracy  
precision  
recall  
F1-score  
ROC-AUC  

Example performance:

Logistic Regression  
Accuracy: 0.83  
ROC-AUC: 0.92  

Random Forest  
Accuracy: 0.80  
ROC-AUC: 0.91  

XGBoost  
Accuracy: 0.81  
ROC-AUC: 0.91  

---

# 16 Visualization Outputs

Plots generated for the paper:

confusion_matrix.png  
roc_curve.png  
feature_importance.png  
correlation_heatmap.png  
shap_feature_importance.png  
shap_summary.png  

Stored in:

paper_assets/05_experiments/

These figures support experimental evaluation.

---

# 17 Explainable AI

Model interpretability implemented using SHAP.

Script:

ml/shap_analysis.py

Outputs:

SHAP feature importance  
SHAP summary plot  

Important predictive signals:

strategy  
weekly_hours  
delay_index_hours  
stability_score  

---

# 18 Model Persistence

Trained model stored as:

models/bridgeup_dropout_model.pkl

Saved using joblib.

Contents:

trained model  
fitted scaler  

This model can be used in future adaptive modules.

---

# 19 Phase 3 Extension

Phase 3 introduces adaptive analytics capability.

Monitoring metrics are now used to predict dropout risk.

Future architecture may use this signal for:

strategy switching  
workload adjustment  
adaptive scheduling  

The predictive module currently operates offline for research evaluation.

---

# 20 System Contributions

BridgeUp provides the following contributions:

constraint-aware learning roadmap generation  
deterministic multi-agent orchestration architecture  
execution lifecycle observability via event logging  
formal monitoring metrics for behavioral evaluation  
predictive dropout risk modeling using monitoring metrics  

---

# 21 Limitations

Current system limitations include:

simulation-based evaluation  
limited dataset size  
file-based persistence  
no real-world user validation  

The predictive model is trained on simulated monitoring data.

---

# 22 Future Work

Future research directions include:

real-world learner deployment  
adaptive strategy adjustment  
reinforcement learning for scheduling optimization  
distributed orchestration architecture  
interactive monitoring dashboards  

---

# 23 System Classification

BridgeUp can be classified as:

a hybrid deterministic multi-agent learning orchestration framework augmented with predictive analytics.

---

END OF DOCUMENT