```markdown
# BridgeUp_DataCollector_Report.md

---

# 1. Module Overview

## Purpose

The Data Collector module is responsible for constructing, normalizing, and persisting the structured datasets required by the BridgeUp multi-agent system. It establishes the foundational knowledge layer used by planning and reasoning agents.

The module produces four core datasets:

- **D1** — Learning Resources Dataset  
- **D2** — Skill & Domain Taxonomy  
- **D3** — Skill-to-Job Role Mapping  
- **D4** — Skill Prerequisite Dependency Graph  

These datasets collectively enable deterministic, constraint-aware roadmap generation.

## Role in BridgeUp Architecture

The Data Collector operates in the **Foundational Data Preparation Phase** of the system lifecycle. It is executed prior to agent invocation and is not active during runtime planning.

Its outputs serve as static, versioned inputs to downstream reasoning agents.

## Phase Classification

- Phase: Pre-Execution / Knowledge Preparation
- Type: Deterministic Data Transformation Module
- Runtime Role: Offline Data Builder

## Design Philosophy

The module adheres to:

- Explicit knowledge modeling over implicit inference
- Deterministic transformation pipelines
- Minimal but sufficient schema design
- Clear separation of dataset responsibilities
- Reproducibility over automation complexity

No dynamic scraping or runtime mutation occurs within this module.

---

# 2. Position in System Architecture

## Upstream Dependencies

- Publicly available course metadata dataset (external CSV)
- Internally defined job role specifications
- Static rule-based inference logic

## Downstream Consumers

- Planning Agent
- Constraint Engine
- Orchestrator
- Evaluation module (future phase)

## Interaction with Other Agents

The Data Collector does not communicate directly with agents.  
It produces versioned datasets consumed by:

- Planning Agent (primary)
- Monitoring & evaluation systems (future phase)

## Invocation Flow

```

Raw Metadata → D1 Builder → D3 Generator → D2 Generator → D4 Generator → Persisted Datasets

```

Execution is sequential and deterministic.

---

# 3. Directory & File Structure

## Folder Layout

```

data/
├── raw/
│   └── D1_kaggle_raw.csv
├── processed/
│   ├── D1_final.csv
│   ├── D2_skill_domain_taxonomy.csv
│   ├── D3_skill_job_mapping.csv
│   └── D4_skill_prerequisites.csv
├── code/
│   ├── D1.py
│   ├── D1_patch.py
│   ├── D2_generate.py
│   ├── D3_generate.py
│   └── D4_generate.py

````

## File Responsibilities

| File | Responsibility |
|------|---------------|
| D1.py | Initial transformation of raw course dataset |
| D1_patch.py | Normalization and schema alignment |
| D3_generate.py | Deterministic job-role skill generation |
| D2_generate.py | Canonical skill taxonomy derivation |
| D4_generate.py | Dependency graph construction |
| processed/*.csv | Final frozen datasets |

Responsibility boundaries are strictly enforced. Each script generates one dataset only.

---

# 4. Core Data Models

The module uses CSV-based structured schemas. No persistent classes are defined beyond pandas dataframes.

## D1 — Learning Resource Model

| Field | Type | Description |
|-------|------|------------|
| resource_id | string | Unique identifier |
| title | string | Course title |
| provider | string | Platform name |
| domain | string | Broad academic domain |
| skill_tags | string | Pipe-separated skill list |
| difficulty | enum | Beginner / Intermediate / Advanced |
| duration_hours | integer | Approximate completion time |
| format | string | Resource format |
| cost_type | string | Free / Paid |
| url | string | Resource link |

---

## D2 — Skill Taxonomy Model

| Field | Type | Description |
|-------|------|------------|
| skill_id | string | Unique skill identifier |
| skill_name | string | Canonical skill name |
| domain | string | Domain classification |
| parent_skill | string | Parent skill reference |
| level | enum | Skill complexity |
| description | string | Textual explanation |

---

## D3 — Job Role Mapping Model

| Field | Type | Description |
|-------|------|------------|
| job_role_id | string | Role identifier |
| job_role_name | string | Role title |
| required_skills | string | Pipe-separated skills |
| skill_weightage | string | Skill:weight pairs |
| domain | string | Role domain |

---

## D4 — Dependency Graph Model

| Field | Type | Description |
|-------|------|------------|
| skill_id | string | Target skill |
| prerequisite_skill_id | string | Required prior skill |
| dependency_type | enum | hard / soft |

---

# 5. Public Interfaces

The module exposes no runtime APIs.  
Execution occurs via standalone scripts.

## Example Invocation

```bash
python data/code/D1.py
python data/code/D3_generate.py
python data/code/D2_generate.py
python data/code/D4_generate.py
````

## Input/Output Behavior

* Input: CSV files
* Output: Structured CSV datasets
* Errors: Standard file I/O or pandas exceptions
* No retry logic implemented

---

# 6. Internal Workflow

## Step 1 — D1 Construction

* Load raw dataset
* Drop unused fields
* Normalize columns
* Parse duration
* Infer difficulty
* Sample fixed-size subset
* Save processed CSV

## Step 2 — D3 Generation

* Define static role-skill mappings
* Assign weightages
* Save mapping CSV

## Step 3 — D2 Generation

* Extract skills from D3
* Merge with D1 skill tags
* Normalize names
* Assign domain
* Infer skill levels
* Assign parent relationships
* Save taxonomy CSV

## Step 4 — D4 Generation

* Traverse D2 parent_skill column
* Create directed edges
* Classify dependencies (hard/soft)
* Save dependency graph CSV

---

# 7. Algorithms & Logic

## Skill Normalization

* Lowercasing
* Trimming whitespace
* Pipe-separated canonicalization

## Domain Inference

Keyword-based rule matching:

* "data", "statistics" → Data Science
* "machine learning" → Machine Learning
* "html", "javascript" → Programming
* "linux", "ci cd" → DevOps

## Dependency Classification

Hard constraints:

* fundamentals → core skill
* statistics → machine learning
* data structures → algorithms

Soft constraints:

* version control → ci cd
* linux → containerization
* javascript → frontend frameworks

## Determinism Strategy

* No randomness except fixed seed sampling
* Fixed role definitions
* Explicit rule-based inference

---

# 8. Integration Points

## With Orchestrator

Datasets are loaded into memory at agent initialization.

## With Planning Agent

Planning agent reads:

* D3 for target skills
* D2 for taxonomy
* D4 for constraints
* D1 for resource selection

## Event System

No event emission in current phase.

## Monitoring

No runtime metrics emitted.

---

# 9. Logging & Observability

Current implementation:

* Console print statements
* Row count reporting
* File creation confirmation

No structured logging implemented.

---

# 10. Determinism & Reliability Guarantees

* Deterministic outputs given identical input
* No network calls
* Idempotent generation
* Replayable pipeline
* No concurrency

Failure scope limited to file system errors.

---

# 11. Configuration & Extensibility

## Tunable Parameters

* Sample size for D1
* Role definitions in D3
* Dependency classification rules

## Extension Points

* Add new job roles
* Expand taxonomy
* Add additional domains
* Introduce probabilistic weighting

No plugin framework implemented.

---

# 12. Current Limitations

* Static skill weight assignments
* Manual dependency heuristics
* No automatic ontology expansion
* No version tracking metadata
* Limited domain diversity

---

# 13. Future Extensions

* Automated role extraction from labor datasets
* Ontology learning from large-scale metadata
* Dynamic dependency modeling
* Version-controlled dataset registry
* Integration with evaluation module (D5–D9)

---

# 14. Usage Examples

## Example Execution

```bash
python data/code/D1.py
python data/code/D3_generate.py
python data/code/D2_generate.py
python data/code/D4_generate.py
```

## Sample Output Snippet (D3)

```
J02,Data Analyst,python|sql|statistics|data visualization|excel,...
```

## Execution Trace

```
D1_final.csv created
D3_skill_job_mapping.csv created
D2_skill_domain_taxonomy.csv created
D4_skill_prerequisites.csv created
```

---

# 15. Summary

The Data Collector module establishes a structured, deterministic knowledge base for BridgeUp. It defines learning resources, canonical skills, career targets, and prerequisite relationships.

The module:

* Is stable
* Is reproducible
* Produces agent-ready datasets
* Does not require runtime interaction
* Supports constraint-based planning

Stability Level: **High (Data Frozen at D4)**
Readiness for Publication: **Suitable for academic documentation**

---

```
```
