# BridgeUp ML Module Technical Report

**Audience:** Planner Chat (System-Level AI Agent)
**Purpose:** Provide a complete technical description of the Machine Learning module implemented for the BridgeUp system, including architecture decisions, dataset generation, preprocessing, model training, evaluation, and explainability components.

---

# 1. Module Overview

The Machine Learning (ML) module was introduced to enable **predictive analytics within the BridgeUp learning orchestration platform**.

BridgeUp is a deterministic multi-agent system consisting of:

* Planning Agent
* Action Agent
* Monitoring Agent
* Orchestrator
* Event System

The Monitoring Agent produces execution metrics during simulated learning sessions. These metrics were used to build a **supervised machine learning model that predicts learner dropout risk**.

The ML module is implemented as an **auxiliary analytics component** and does not modify the orchestration logic.

---

# 2. Integration Point in BridgeUp Architecture

Data flow for ML integration:

```
Planning Agent
      ↓
Action Agent executes tasks
      ↓
Monitoring Agent logs execution metrics
      ↓
Session metrics exported to CSV
      ↓
ML preprocessing pipeline
      ↓
Dropout prediction model
      ↓
Analytics and explainability outputs
```

The ML module operates **offline for analysis and research evaluation**.

---

# 3. Dataset Generation

## 3.1 Source of Data

Dataset generated from monitoring metrics produced during simulated lifecycle execution.

File location:

```
paper_assets/03_metrics/metrics_v1.csv
```

Each row represents **one learner session**.

Example schema:

```
session_id
strategy
weekly_hours
total_tasks
completed_tasks
missed_tasks
completion_rate
delay_index_hours
workload_utilization
stability_score
dropoff_risk
consistency_score
```

---

## 3.2 Behavioral Simulation

The dataset was generated using:

```
experiments/run_phase2_5.py
```

This script performs:

1. Orchestrator initialization
2. Planning + scheduling
3. Lifecycle simulation of learner behavior
4. Monitoring metric computation
5. CSV export

The lifecycle simulation implements **strategy-based behavior models**.

Strategies:

```
fast
balanced
deep
```

Each strategy defines:

```
completion_ratio
completion_delay
miss_delay
```

To prevent deterministic outputs, stochastic variation was introduced using:

```
random.uniform()
```

Example behavioral variation:

```
completion_ratio = random.uniform(0.5, 0.7)
completion_delay_hours = random.uniform(-3, 1)
miss_delay_hours = random.uniform(1, 4)
```

This ensures the generated dataset contains realistic variability.

---

# 4. ML Dataset Preparation

## 4.1 Dataset Builder

Script:

```
ml/build_ml_dataset.py
```

Purpose:

Convert monitoring dataset into ML-ready dataset.

Process:

1. Load monitoring CSV
2. Generate binary label
3. Select ML features
4. Save processed dataset

Target label:

```
dropout_label = (dropoff_risk >= 0.3)
```

Output dataset:

```
paper_assets/03_metrics/metrics_ml_ready.csv
```

Final dataset schema:

```
strategy
weekly_hours
delay_index_hours
workload_utilization
stability_score
consistency_score
dropout_label
```

---

# 5. Feature Engineering

Implemented in:

```
ml/preprocessing.py
```

## 5.1 Strategy Encoding

Categorical feature converted to numeric:

```
fast → 0
balanced → 1
deep → 2
```

---

## 5.2 Interaction Features

Two engineered features added:

```
delay_workload = delay_index_hours * workload_utilization

stability_consistency = stability_score * consistency_score
```

Purpose:

Capture nonlinear interactions between behavioral metrics.

Final feature set:

```
strategy
weekly_hours
delay_index_hours
workload_utilization
stability_score
consistency_score
delay_workload
stability_consistency
```

---

# 6. Model Training

Script:

```
ml/train_model.py
```

Training pipeline:

```
Load dataset
↓
Feature preparation
↓
Standard scaling
↓
Train-test split
↓
Model training
↓
Model persistence
```

Scaler:

```
StandardScaler
```

Split configuration:

```
test_size = 0.2
stratify = y
random_state = 42
```

---

# 7. Models Implemented

Three models were trained.

## 7.1 Logistic Regression

```
LogisticRegression(
    C=0.5,
    max_iter=300
)
```

Purpose:

Baseline linear classifier.

---

## 7.2 Random Forest

```
RandomForestClassifier(
    n_estimators=400,
    max_depth=10,
    min_samples_split=4,
    min_samples_leaf=2
)
```

Purpose:

Tree ensemble for nonlinear decision boundaries.

---

## 7.3 XGBoost

```
XGBClassifier(
    n_estimators=400,
    max_depth=5,
    learning_rate=0.05,
    subsample=0.9,
    colsample_bytree=0.9
)
```

Purpose:

Gradient boosting model optimized for tabular data.

---

# 8. Model Evaluation

Evaluation implemented in:

```
ml/evaluate_models.py
```

Validation method:

```
StratifiedKFold
n_splits = 5
shuffle = True
```

Evaluation metrics:

```
Accuracy
Precision
Recall
F1-score
ROC-AUC
```

Example results:

```
Model                Accuracy   Precision   Recall   F1    ROC-AUC
Logistic Regression   0.83       0.83        0.93    0.87    0.92
Random Forest         0.80       0.82        0.87    0.84    0.91
XGBoost               0.81       0.83        0.87    0.85    0.91
```

---

# 9. Visualization Outputs

Generated using:

```
ml/generate_plots.py
```

Outputs stored in:

```
paper_assets/05_experiments/
```

Generated plots:

```
confusion_matrix.png
roc_curve.png
feature_importance.png
```

Purpose:

Provide interpretable model evaluation artifacts.

---

# 10. Correlation Analysis

Script:

```
ml/correlation_heatmap.py
```

Generates correlation matrix across monitoring metrics.

Output:

```
correlation_heatmap.png
```

Purpose:

Identify relationships between behavioral metrics and dropout label.

---

# 11. Explainable AI (SHAP)

Explainability implemented in:

```
ml/shap_analysis.py
```

SHAP analysis performed using:

```
shap.TreeExplainer
```

Outputs:

```
shap_feature_importance.png
shap_summary.png
```

These plots reveal:

* Feature influence magnitude
* Directional impact on predictions

Key predictive signals:

```
strategy
weekly_hours
stability_score
delay_index_hours
```

---

# 12. Model Persistence

Trained model stored as:

```
models/bridgeup_dropout_model.pkl
```

Saved using:

```
joblib.dump()
```

Contents:

```
{
    "model": trained_model,
    "scaler": fitted_scaler
}
```

---

# 13. ML Module File Structure

```
BridgeUp/ml/

build_ml_dataset.py
preprocessing.py
train_model.py
evaluate_models.py
generate_plots.py
correlation_heatmap.py
shap_analysis.py
```

Output artifacts:

```
models/bridgeup_dropout_model.pkl

paper_assets/05_experiments/
    confusion_matrix.png
    roc_curve.png
    feature_importance.png
    correlation_heatmap.png
    shap_feature_importance.png
    shap_summary.png
```

---

# 14. Summary of ML Contribution

The ML module adds predictive capability to the BridgeUp monitoring framework by:

1. Transforming monitoring logs into ML datasets
2. Training dropout prediction models
3. Evaluating multiple classifiers
4. Producing interpretable analytics
5. Providing explainable AI insights

This module demonstrates that **behavioral monitoring metrics generated by the BridgeUp multi-agent system can be used to predict learner disengagement risk**.

The implementation maintains strict separation from the core orchestration pipeline and operates as a **research evaluation layer**.

---

END OF REPORT
