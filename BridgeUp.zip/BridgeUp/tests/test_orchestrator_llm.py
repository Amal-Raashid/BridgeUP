from agents.orchestrator_agent.orchestrator import Orchestrator
from agents.orchestrator_agent.state import SessionState
from datetime import datetime

def test_orchestrator_with_llm():

    orchestrator = Orchestrator()

    state = SessionState()

    request = {
        "job_requirement": "Backend Developer",
        "known_skills": ["Python"],
        "weekly_time_hours": 10,
        "strategy": "balanced",
        "request_type": "generate_plan_and_execute",
        "start_date": datetime(2026, 3, 5)
    }

    response = orchestrator.handle_request(request, state)

    print("\n===== ORCHESTRATOR RESPONSE =====\n")
    print(response)

    print("\n===== LLM ADVISORY =====\n")
    print(state.planning_state.explainability_notes)

    print("\n===== MONITORING REPORT =====\n")
    print(state.monitoring_state.monitoring_report)

    print("\n===== SELECTED STRATEGY (Deterministic) =====\n")
    print(state.planning_state.selected_strategy)


if __name__ == "__main__":
    test_orchestrator_with_llm()