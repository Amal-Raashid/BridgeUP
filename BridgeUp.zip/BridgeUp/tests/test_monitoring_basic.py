from pathlib import Path
from datetime import datetime, timedelta

from agents.monitoring_agent import MonitoringAgent

BASE_PATH = Path("data/monitoring_logs")

monitor = MonitoringAgent(BASE_PATH)

session_id = "test_session_1"

now = datetime.utcnow()

# -----------------------------
# Create Tasks
# -----------------------------

for i in range(3):

    created = now
    start = now + timedelta(hours=i)
    deadline = start + timedelta(hours=2)

    monitor.collector.record_task_event({
        "event_type": "TASK_CREATED",
        "task_id": f"task_{i}",
        "session_id": session_id,
        "timestamp": created.isoformat(),
        "payload": {
            "strategy_type": "FAST",
            "scheduled_start": start.isoformat(),
            "deadline": deadline.isoformat(),
        },
    })

    monitor.collector.record_task_event({
        "event_type": "TASK_STARTED",
        "task_id": f"task_{i}",
        "session_id": session_id,
        "timestamp": start.isoformat(),
        "payload": {},
    })

    monitor.collector.record_task_event({
        "event_type": "TASK_COMPLETED",
        "task_id": f"task_{i}",
        "session_id": session_id,
        "timestamp": (deadline - timedelta(minutes=30)).isoformat(),
        "payload": {},
    })

# -----------------------------
# Build Snapshot
# -----------------------------

monitor.collector.build_session_snapshot(
    session_id=session_id,
    weekly_hours_allocated=10,
    planned_days=7,
)

# -----------------------------
# Verify Outputs
# -----------------------------

metrics = monitor.get_session_metrics(session_id)
risk = monitor.get_risk_profile(session_id)
summary = monitor.get_execution_summary(session_id)

print("Completion Rate:", metrics.completion_rate)
print("Stability Score:", metrics.stability_score)
print("Risk Level:", risk.risk_level)
print("Summary:", summary.progress_status)