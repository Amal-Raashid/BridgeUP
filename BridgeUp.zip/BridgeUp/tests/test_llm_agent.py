import os
from agents.llm_agent.reasoning_engine import LLMReasoningEngine

def test_strategy_suggestion():
    engine = LLMReasoningEngine()

    result = engine.suggest_strategy(
        user_goal="Become a backend developer in 6 months",
        weekly_hours=10,
        known_skills=["Python basics"]
    )

    print("\n--- Strategy Suggestion ---")
    print(result.model_dump())

    assert result.suggested_strategy in ["FAST", "BALANCED", "DEEP"]
    assert 0.0 <= result.confidence <= 1.0
    assert isinstance(result.tradeoffs, list)


def test_api_intent():
    engine = LLMReasoningEngine()

    result = engine.analyze_user_goal(
        user_goal="What is the job market demand for backend developers in India?"
    )

    print("\n--- API Intent ---")
    print(result.model_dump())

    assert result.intent_type in [
        "FETCH_JOB_MARKET_DATA",
        "FETCH_CERTIFICATION_COURSES",
        "FETCH_SALARY_TRENDS",
        "NO_EXTERNAL_QUERY"
    ]


if __name__ == "__main__":
    test_strategy_suggestion()
    test_api_intent()