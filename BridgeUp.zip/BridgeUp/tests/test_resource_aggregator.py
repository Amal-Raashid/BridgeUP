from integrations.resource_aggregator import ResourceAggregator


def test_aggregator():

    aggregator = ResourceAggregator()

    resources = aggregator.collect_by_skill("machine learning")

    print("\nRESOURCE SUMMARY\n")

    print("Jobs:", len(resources.jobs))
    print("Projects:", len(resources.projects))
    print("Courses:", len(resources.courses))
    print("Tutorials:", len(resources.tutorials))

    if resources.jobs:
        print("\nSample Job:", resources.jobs[0])

    if resources.projects:
        print("\nSample Project:", resources.projects[0])

    if resources.courses:
        print("\nSample Course:", resources.courses[0])

    if resources.tutorials:
        print("\nSample Tutorial:", resources.tutorials[0])


if __name__ == "__main__":
    test_aggregator()