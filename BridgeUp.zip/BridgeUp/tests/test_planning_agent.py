"""
Basic tests for Planning Agent.
"""

import pytest

from agents.planning_agent.models import Task
from agents.planning_agent.constraints import DependencyConstraint
from agents.planning_agent.planner import PlanningAgent


def test_plan_creation_with_valid_dependencies():
    tasks = [
        Task(id="task-1", title="First task"),
        Task(id="task-2", title="Second task", dependencies=["task-1"]),
    ]

    agent = PlanningAgent(
        constraints=[DependencyConstraint()]
    )

    plan = agent.create_plan(tasks)

    assert plan.plan_id == "plan-1"
    assert len(plan.steps) == 2
    assert plan.steps[0].task_id == "task-1"
    assert plan.steps[1].task_id == "task-2"


def test_plan_fails_on_missing_dependency():
    tasks = [
        Task(id="task-1", title="First task", dependencies=["task-X"]),
    ]

    agent = PlanningAgent(
        constraints=[DependencyConstraint()]
    )

    with pytest.raises(ValueError):
        agent.create_plan(tasks)


def test_dependency_ordering():
    tasks = [
        Task(id="task-1", title="Root task"),
        Task(id="task-2", title="Depends on task-1", dependencies=["task-1"]),
        Task(id="task-3", title="Depends on task-2", dependencies=["task-2"]),
    ]

    agent = PlanningAgent(
        constraints=[DependencyConstraint()]
    )

    plan = agent.create_plan(tasks)

    ordered_task_ids = [step.task_id for step in plan.steps]

    assert ordered_task_ids == ["task-1", "task-2", "task-3"]


def test_circular_dependency_detection():
    tasks = [
        Task(id="task-1", title="Task 1", dependencies=["task-2"]),
        Task(id="task-2", title="Task 2", dependencies=["task-1"]),
    ]

    agent = PlanningAgent(
        constraints=[DependencyConstraint()]
    )

    with pytest.raises(ValueError, match="Circular dependency"):
        agent.create_plan(tasks)
