from integrations.course_api_client import CourseAPIClient


def test_courses():

    client = CourseAPIClient()

    courses = client.query_by_skill("machine learning")

    print("Total courses:", len(courses))

    if courses:
        print("Sample course:")
        print(courses[0])


if __name__ == "__main__":
    test_courses()