from uuid import uuid4
from datetime import datetime, timezone

from BridgeUp.events.schema import Event, EventType, EVENT_SCHEMA_VERSION
from BridgeUp.events.validator import validate_event
from BridgeUp.events.logger import append_event


def run_test():
    event = Event(
        event_id=uuid4(),
        version=EVENT_SCHEMA_VERSION,
        timestamp=datetime.now(timezone.utc),
        session_id="logger_test",
        agent="orchestrator",
        event_type=EventType.SESSION_STARTED,
        payload={"user_id": "test_user"},
        metadata={}
    )

    validate_event(event)
    append_event(event)

    print("✅ Event written successfully")


if __name__ == "__main__":
    run_test()