from integrations.github_api_client import GitHubAPIClient
from integrations.job_api_client import JobAPIClient
from integrations.course_api_client import CourseAPIClient
from integrations.tutorial_api_client import TutorialAPIClient


def test_resource_pipeline():

    skill = "machine learning"

    jobs = JobAPIClient().query_by_skill(skill)
    courses = CourseAPIClient().query_by_skill(skill)
    projects = GitHubAPIClient().query_by_skill(skill)
    tutorials = TutorialAPIClient().query_by_skill(skill)

    print("\nRESOURCE SUMMARY")
    print("jobs:", len(jobs))
    print("courses:", len(courses))
    print("projects:", len(projects))
    print("tutorials:", len(tutorials))