from datetime import datetime
from agents.orchestrator_agent import Orchestrator, SessionState


def test_planning_workflow():

    orchestrator = Orchestrator()
    state = SessionState()

    request = {
        "job_requirement": "Backend Developer",
        "known_skills": ["Python"],
        "weekly_time_hours": 10,
        "strategy": "balanced",
        "request_type": "generate_plan_and_execute",
        "start_date": datetime.utcnow(),
    }

    response = orchestrator.handle_request(request, state)

    print("RESPONSE:")
    print(response)
    print("\nSTATE:")
    print(state)


if __name__ == "__main__":
    test_planning_workflow()
