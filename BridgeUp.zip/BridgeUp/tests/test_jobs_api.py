from integrations.job_api_client import JobAPIClient


def test_jobs():

    client = JobAPIClient()

    jobs = client.query_by_skill("python")

    print("Total jobs:", len(jobs))

    sources = set()

    for job in jobs:
        sources.add(job.source)

    print("Sources found:", sources)

    if jobs:
        print("Sample job:")
        print(jobs[0])


if __name__ == "__main__":
    test_jobs()