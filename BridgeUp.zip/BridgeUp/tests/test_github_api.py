from integrations.github_api_client import GitHubAPIClient


def test_github_projects():

    client = GitHubAPIClient()

    projects = client.query_by_skill("machine learning")

    print("Total projects:", len(projects))

    if projects:
        print("Sample project:")
        print(projects[0])


if __name__ == "__main__":
    test_github_projects()