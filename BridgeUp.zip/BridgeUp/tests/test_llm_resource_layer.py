from integrations.resource_aggregator import ResourceAggregator
from agents.llm_agent.reasoning_engine import LLMReasoningEngine


def test_resource_intelligence():

    aggregator = ResourceAggregator()
    llm = LLMReasoningEngine()

    skill = "machine learning"

    print("\n=== COLLECTING RESOURCES ===\n")

    resources = aggregator.collect_by_skill(skill)

    print("Jobs:", len(resources.jobs))
    print("Projects:", len(resources.projects))
    print("Courses:", len(resources.courses))
    print("Tutorials:", len(resources.tutorials))

    print("\n=== RANKING RESOURCES ===\n")

    ranked = llm.rank_resources(resources)

    print(ranked)

    print("\n=== GENERATING LEARNING PLAN ===\n")

    plan = llm.generate_learning_plan(
        resources,
        ranked
    )

    print(plan)

    print("\n=== RESOURCE EXPLANATIONS ===\n")

    explanations = llm.generate_resource_explanations(
        skill,
        ranked
    )

    print(explanations)


if __name__ == "__main__":
    test_resource_intelligence()