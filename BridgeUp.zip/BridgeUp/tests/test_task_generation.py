# tests/test_task_generation.py

class DummyResource:
    def __init__(self, resource_id, title, estimated_minutes):
        self.resource_id = resource_id
        self.title = title
        self.estimated_minutes = estimated_minutes


class DummyStep:
    def __init__(self, step_id, resources):
        self.step_id = step_id
        self.resources = resources


class DummyRoadmap:
    def __init__(self, roadmap_id, steps):
        self.roadmap_id = roadmap_id
        self.steps = steps


def test_generate_tasks():
    from agents.action_agent.executor import generate_tasks_from_roadmap

    roadmap = DummyRoadmap(
        roadmap_id="rm1",
        steps=[
            DummyStep(
                "s1",
                [
                    DummyResource("r1", "Intro", 60),
                    DummyResource("r2", "Advanced", 90)
                ]
            )
        ]
    )

    tasks = generate_tasks_from_roadmap(roadmap)

    assert len(tasks) == 2
    assert tasks[0].task_id == "rm1:s1:r1"
    assert tasks[1].estimated_minutes == 90


if __name__ == "__main__":
    test_generate_tasks()
    print("Test passed.")