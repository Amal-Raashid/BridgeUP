from BridgeUp.events.emitter import emit_orchestrator_event
from BridgeUp.events.schema import EventType


def run_test():
    emit_orchestrator_event(
        event_type=EventType.SESSION_STARTED,
        session_id="emitter_test",
        payload={"user_id": "u_001"},
    )

    print("✅ Emitter executed successfully")


if __name__ == "__main__":
    run_test()