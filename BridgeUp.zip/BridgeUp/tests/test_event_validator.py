from uuid import uuid4
from datetime import datetime, timezone

from BridgeUp.events.schema import Event, EventType, EVENT_SCHEMA_VERSION
from BridgeUp.events.validator import validate_event


def test_valid_event():
    event = Event(
        event_id=uuid4(),
        version=EVENT_SCHEMA_VERSION,
        timestamp=datetime.now(timezone.utc),
        session_id="session_123",
        agent="orchestrator",
        event_type=EventType.SESSION_STARTED,
        payload={"user_id": "user_001"},
        metadata={}
    )

    validate_event(event)
    print("✅ Validation PASSED")


def test_invalid_event():
    try:
        event = Event(
            event_id=uuid4(),
            version=EVENT_SCHEMA_VERSION,
            timestamp=datetime.now(timezone.utc),
            session_id="session_123",
            agent="orchestrator",
            event_type=EventType.SESSION_STARTED,
            payload={},  # Missing required user_id
            metadata={}
        )

        validate_event(event)

    except Exception as e:
        print("✅ Correctly caught validation error:")
        print(e)


if __name__ == "__main__":
    print("Running Event Validator Tests...\n")

    test_valid_event()
    print()

    test_invalid_event()