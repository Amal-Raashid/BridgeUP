from integrations.tutorial_api_client import TutorialAPIClient


def test_tutorials():

    client = TutorialAPIClient()

    tutorials = client.query_by_skill("python")

    print("Total tutorials:", len(tutorials))

    if tutorials:
        print("Sample tutorial:")
        print(tutorials[0])


if __name__ == "__main__":
    test_tutorials()